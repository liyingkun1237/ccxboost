from distutils.core import setup

setup(
    name='ccxboost',
    version='0.1.1',
    packages=['ccxboost'],
    url='2017-08-03',
    license='ccx',
    author='liyingkun',
    author_email='liyingkun@ccx.cn',
    description='中诚信征信机器学习平台--boost模型',
    package_data={'': ['*.conf']}
)
